<?php

namespace Combodo\iTop\Core\Notification\Action\Webhook\Exception;

/**
 * @since 1.1.2 N°5473 class creation
 */
class WebhookInvalidJsonValueException extends \CoreUnexpectedValue
{

}