<?php
//
// Dictionary index built by the compiler
//
Dict::SetLanguagesList(
array (
  'CS CZ' => 
  array (
    'description' => 'Czech',
    'localized_description' => 'Čeština',
  ),
  'DA DA' => 
  array (
    'description' => 'Danish',
    'localized_description' => 'Dansk',
  ),
  'DE DE' => 
  array (
    'description' => 'German',
    'localized_description' => 'Deutsch',
  ),
  'EN US' => 
  array (
    'description' => 'English',
    'localized_description' => 'English',
  ),
  'ES CR' => 
  array (
    'description' => 'Spanish',
    'localized_description' => 'Español, Castellano',
  ),
  'FR FR' => 
  array (
    'description' => 'French',
    'localized_description' => 'Français',
  ),
  'HU HU' => 
  array (
    'description' => 'Hungarian',
    'localized_description' => 'Magyar',
  ),
  'IT IT' => 
  array (
    'description' => 'Italian',
    'localized_description' => 'Italiano',
  ),
  'JA JP' => 
  array (
    'description' => 'Japanese',
    'localized_description' => '日本語',
  ),
  'NL NL' => 
  array (
    'description' => 'Dutch',
    'localized_description' => 'Nederlands',
  ),
  'PL PL' => 
  array (
    'description' => 'Polish',
    'localized_description' => 'Polski',
  ),
  'PT BR' => 
  array (
    'description' => 'Brazilian',
    'localized_description' => 'Brazilian',
  ),
  'RU RU' => 
  array (
    'description' => 'Russian',
    'localized_description' => 'Русский',
  ),
  'SK SK' => 
  array (
    'description' => 'Slovak',
    'localized_description' => 'Slovenčina',
  ),
  'TR TR' => 
  array (
    'description' => 'Turkish',
    'localized_description' => 'Türkçe',
  ),
  'ZH CN' => 
  array (
    'description' => 'Chinese',
    'localized_description' => '简体中文',
  ),
)
);